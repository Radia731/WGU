# Letters

<strong>[EN]</strong>

Letters is a display typeface available in regular and italic styles. Designed for experimental use, it performs best at large sizes.

It derives from a historical interest in the depiction of paper within the realm of printed matter, such as teared ribbons and ornamental backgrounds. It’s a silly examination that tries to render the material quality of paper through the world of vectors, eventually finding a way back onto the paper and therefore living in the false self. 

Letters is rooted in historical research conducted at the Huis van het Boek archive in The Hague, complemented by hands-on material investigations. Its development has spanned three years, following an organic and intentionally illogical process of burning paper, reviewing historical sources, tracing photographs, and endlessly refining Bézier curves.

Letters has been created by Céline Hurka (www.celine-hurka.com - celine.hurka@gmail.com) and Jules Janssen (https://julesjanssen.biz - info@julesjanssen.biz) and released under the SIL Open Font Licence 1.1 in 2025. Letters is distributed by Velvetyne Type Foundry (http://velvetyne.fr/).

To know how to use this typeface, please read the FAQ (http://velvetyne.fr/about/faq/)

## Specimen

![specimen1](documentation/specimen/letters-lavish-1.jpg)
![specimen2](documentation/specimen/letters-lavish-2.jpg)
![specimen3](documentation/specimen/letters-torn-1.jpg)
![specimen4](documentation/specimen/letters-torn-2.jpg)

## License

Letters is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at
http://scripts.sil.org/OFL

## Repository Layout

This font repository follows the Unified Font Repository v2.0,
a standard way to organize font project source files. Learn more at
https://github.com/unified-font-repository/Unified-Font-Repository
